/* ============================================================
   RootX Theme — Global JavaScript
   ============================================================ */

(function () {
  'use strict';

  /* ── Mobile Menu Toggle ────────────────────────────────────── */

  var menuToggle = document.querySelector('.mobile-menu-toggle');
  var mainNav = document.querySelector('.main-nav');

  if (menuToggle && mainNav) {
    menuToggle.addEventListener('click', function () {
      var isOpen = mainNav.classList.toggle('is-open');
      menuToggle.setAttribute('aria-expanded', String(isOpen));
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    // Close menu on ESC
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mainNav.classList.contains('is-open')) {
        mainNav.classList.remove('is-open');
        menuToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
        menuToggle.focus();
      }
    });

    // Close menu when clicking outside
    document.addEventListener('click', function (e) {
      if (
        mainNav.classList.contains('is-open') &&
        !mainNav.contains(e.target) &&
        !menuToggle.contains(e.target)
      ) {
        mainNav.classList.remove('is-open');
        menuToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      }
    });
  }

  /* ── FAQ Accordion Toggle ──────────────────────────────────── */

  var faqToggles = document.querySelectorAll('[data-faq-toggle]');

  faqToggles.forEach(function (toggle) {
    toggle.addEventListener('click', function () {
      var item = toggle.closest('[data-faq-item]');
      var answer = item ? item.querySelector('.faq-answer') : null;
      if (!answer) return;

      var isExpanded = toggle.getAttribute('aria-expanded') === 'true';

      // Close all other FAQ items
      faqToggles.forEach(function (otherToggle) {
        if (otherToggle !== toggle) {
          otherToggle.setAttribute('aria-expanded', 'false');
          var otherItem = otherToggle.closest('[data-faq-item]');
          var otherAnswer = otherItem ? otherItem.querySelector('.faq-answer') : null;
          if (otherAnswer) {
            otherAnswer.hidden = true;
            otherAnswer.style.maxHeight = null;
          }
        }
      });

      // Toggle current
      toggle.setAttribute('aria-expanded', String(!isExpanded));
      if (isExpanded) {
        answer.style.maxHeight = null;
        setTimeout(function () { answer.hidden = true; }, 300);
      } else {
        answer.hidden = false;
        answer.style.maxHeight = answer.scrollHeight + 'px';
      }
    });
  });

  /* ── Smooth Scroll for Anchor Links ────────────────────────── */

  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      var href = anchor.getAttribute('href');
      if (!href || href === '#') return;

      var target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });

        // Update URL without jump
        if (history.pushState) {
          history.pushState(null, '', href);
        }
      }
    });
  });

  /* ── Quantity Selectors ────────────────────────────────────── */

  document.querySelectorAll('[data-quantity-minus]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = btn.parentElement ? btn.parentElement.querySelector('.quantity-input') : null;
      if (!input) return;
      var val = parseInt(input.value, 10) || 1;
      if (val > 1) {
        input.value = String(val - 1);
        input.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  });

  document.querySelectorAll('[data-quantity-plus]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = btn.parentElement ? btn.parentElement.querySelector('.quantity-input') : null;
      if (!input) return;
      var val = parseInt(input.value, 10) || 0;
      input.value = String(val + 1);
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });

  /* ── Cart Quantity Auto-Update ──────────────────────────────── */

  document.querySelectorAll('.cart-item .quantity-input').forEach(function (input) {
    input.addEventListener('change', function () {
      var line = input.getAttribute('data-line');
      var quantity = parseInt(input.value, 10);
      if (!line || isNaN(quantity) || quantity < 0) return;

      fetch('/cart/change.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ line: parseInt(line, 10), quantity: quantity }),
      })
        .then(function () {
          window.location.reload();
        })
        .catch(function (err) {
          console.error('Cart update failed:', err);
        });
    });
  });

  /* ── Product Gallery Thumbnails ────────────────────────────── */

  var thumbnails = document.querySelectorAll('[data-gallery-thumb]');
  var galleryItems = document.querySelectorAll('[data-gallery-item]');

  thumbnails.forEach(function (thumb) {
    thumb.addEventListener('click', function () {
      var index = parseInt(thumb.getAttribute('data-gallery-thumb') || '0', 10);

      // Update active states
      thumbnails.forEach(function (t) { t.classList.remove('product-thumbnail--active'); });
      galleryItems.forEach(function (g) { g.classList.remove('product-gallery__item--active'); });

      thumb.classList.add('product-thumbnail--active');
      if (galleryItems[index]) {
        galleryItems[index].classList.add('product-gallery__item--active');
      }
    });
  });

  // Only show active gallery item
  galleryItems.forEach(function (item) {
    if (!item.classList.contains('product-gallery__item--active')) {
      item.style.display = 'none';
    }
  });

  if (galleryItems.length > 0) {
    thumbnails.forEach(function (thumb) {
      thumb.addEventListener('click', function () {
        galleryItems.forEach(function (g) { g.style.display = 'none'; });
        var index = parseInt(thumb.getAttribute('data-gallery-thumb') || '0', 10);
        if (galleryItems[index]) {
          galleryItems[index].style.display = 'block';
        }
      });
    });
  }
})();